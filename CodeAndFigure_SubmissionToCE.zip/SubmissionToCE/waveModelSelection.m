% clc,clear
H = 2;
h = 10;
T = 1;

% find wave length 
ResultsZhao =   StokesDispSolver('h',h,'T', T, 'H',H);
L_Stokes = ResultsZhao.L
L = L_Stokes;
Ur_Zhao_and_Liu = H/L_Stokes/(h/L_Stokes)^3

if Ur_Zhao_and_Liu >26
    fprintf('Ur > 26, checking with cnoidal wave solutions')
ResultsFenton = FentonWaveLSolver('h',h,'T', T, 'H',H);
if ResultsFenton.m(1) > 0.96
   L_cnoidal = ResultsFenton.L(2)
else
   L_cnoidal = ResultsFenton.L(1)
end
L = L_cnoidal;
Ur_Fen = H/L_cnoidal/(h/L_cnoidal)^3
else
end
Results =[]
Results = [Results; h/L, H/L];
%% % plot on the redrawn Le Mehaute's chart
  openfig('Redrawn_Chart_periodicalWave_CE.fig')
%   ylim([0.001 0.2])

xlabel('h/L');
ylabel('H/L');
% tightfig
hold on, 
plot(h/L, H/L, 'ro', 'markerface','r', 'markersize',9)