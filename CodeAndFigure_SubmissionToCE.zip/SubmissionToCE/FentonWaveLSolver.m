%% plot m curves based on Fenton's cnoidal wave solutions
% Case for given H, h, T
% mean depth h, --> equivalent to d in Fenton's paper. 
% Results =FentonWaveLSolver('h',10,'T', 12, 'H',2)
function [Result] = FentonWaveLSolver(varargin)
names = varargin(1:2:end);
values = varargin(2:2:end);
for kIn = 1:numel(names)
    switch names{kIn}
        case 'H'
            H = values{kIn};
        case 'h'
            h = values{kIn};
        case 'T'
            T = values{kIn};
    end
end
g = 9.81; 

syms m
for i = 0:1
    
[Km, Em] = ellipke(m);
em = Em./Km;
Hoverh = H./h;
% 3rd order 
% Fentons (1999) - Eqn A.8, denote third order symbols with 3
doverh3 =1+H/m./h.*(1-m-em)+(H/m./h).^2.*(-1/2+1/2.*m+(1/2-1/4.*m).*em)+....
    (H/m./h).^3.*(133/200 -399/400*m+133/400*m.^2+(-233/200+233/200*m-1/25*m.^2)*em...
    +(1/2-1/4.*m).*em.^2); % h/d, A.8
d3 = doverh3.*h; % trough depth in this code is represented by d, 
epsilon = H./d3;
epsOverm = epsilon./m;
% Fentons (1999) - Eqn A.6
uBar31 = sqrt(g.*d3).*(1+epsOverm.*(1/2-em) + epsOverm.^2.*(-13/120-m/60-m.^2/40+(1/3+m/12).*em)+ ...
    epsOverm.^3.*(-361/2100+1899*m/5600-2689*m.^2/16800+13*m.^3/280+...
    (7/75-103*m/300+131*m.^2/600).*em));
% Fentons (1999) - Eqn A.7
L3 = (4*Km./sqrt(3*H/m./h).*(1+H/m./h.*(5/4-5/8*m-3/2.*em)+...
    (H/m./h).^2.*(-15/32+15/32.*m-21/128.*m.^2+(1/8-1/16*m)*em+3/8.*em.^2))).*h;
uBar32 = L3./T;
if i == 0
    msol3 = double(vpasolve(uBar32 - uBar31, m, [0.5 1])); 
    m = msol3;
end
end
syms m

for i = 0:1
 
[Km, Em] = ellipke(m);
em = Em./Km;
Hoverh = H./h;
% fifth order
% h/d, B.8, denote third order symbols with 5
doverh5 = 1+Hoverh.*(-em)+Hoverh.^2.*em/4+Hoverh.^3.*(-1/25.*em+1/4*em.^2)...
    +Hoverh.^4.*(573/2000.*em-57.*em.^2/400+1/4.*em.^3)+Hoverh.^5*(-302159/1470000.*em+...
    1779/2000.*em.^2-123/400.*em.^3+1/4*em.^4);
d5 = doverh5.*h;
Hoverd = H./d5; 
% Fentons (1999) - Eqn B.6
uBar51 = sqrt(g*d5)*(1+Hoverd*(1/2-em) + Hoverd.^2.*(-3/20+5.*em/12) + ...
    Hoverd.^3.*(3/56-19*em/600)+Hoverd.^4*(-309/5600+3719*em/21000) +...
    Hoverd.^5*(12237/616000 - 997699*em/8820000));
% Fentons (1999) - Eqn B.7 in his work on cnoidal wave
L5 = (4*Km./sqrt(3*Hoverh).*(1+Hoverh.*(5/8-3/2.*em)+...
    Hoverh.^2.*(-21/128+1/16.*em+3/8.*em.^2)+Hoverh.^3.*(20127/179200-...
    409/6400.*em+7/64.*em.^2+1/16.*em.^3)+...
    Hoverh.^4.*(-1575087/28672000+1086367/1792000.*em-2679/25600.*em.^2+...
    13/128.*em.^3+3/128.*em.^4))).*h;
uBar52 = L5./T; %celerity without current
if i == 0
    msol5 = double(vpasolve(uBar52 - uBar51, m,[0.5 1])); 
    m = msol5;
end
end
% first column as 3rd order solution, and second colomn as 5th order sol
Result.h = h;
Result.H = H;
Result.T = T;
Result.m = [msol3, msol5];
Result.d = [d3, d5];
Result.L = [L3, L5];
Result.c = [uBar32, uBar52];

end

    
